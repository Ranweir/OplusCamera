package com.camera.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.Locale;

/** Arch-shaped zoom dial: orange zoom label, scrolling ticks, orange needle. */
public class ZoomDialView extends View {
    private static final int ORANGE = 0xFFEF8A3F;

    private final float d;
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint();
    private final Paint needle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mask = new Paint();
    private final Path arch = new Path();
    private final RectF oval = new RectF();
    private float zoom = 1f;

    public ZoomDialView(Context c) { this(c, null); }

    public ZoomDialView(Context c, AttributeSet a) {
        super(c, a);
        d = getResources().getDisplayMetrics().density;
        text.setColor(ORANGE);
        text.setTextSize(16f * d);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextAlign(Paint.Align.CENTER);
        text.setShadowLayer(4f * d, 0f, d, 0xFF000000);
        bg.setColor(0xAA000000);
        tick.setColor(0xDDFFFFFF);
        tick.setStrokeWidth(2f * d);
        needle.setColor(ORANGE);
        needle.setStrokeWidth(3f * d);
        needle.setStrokeCap(Paint.Cap.ROUND);
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    public void setZoom(float z) {
        zoom = z;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float aw = w * 0.92f;
        float left = (w - aw) / 2f;
        mask.setShader(new LinearGradient(left, 0f, left + aw, 0f,
                new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                new float[]{0f, 0.25f, 0.75f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float archH = 40f * d;
        float aw = w * 0.92f;
        float left = (w - aw) / 2f, right = left + aw;
        float top = h - archH, bottom = h;

        c.drawText(String.format(Locale.US, "%.1f\u00D7", zoom), w / 2f, top - 8f * d, text);

        oval.set(left, top, right, top + 2f * archH);
        arch.reset();
        arch.arcTo(oval, 180f, 180f, true);
        arch.close();

        int sc = c.saveLayer(left, top, right, bottom, null);
        c.drawPath(arch, bg);

        c.save();
        c.clipPath(arch);
        float period = 14f * d;
        float off = (float) (-(Math.log(zoom) / Math.log(2.0)) * 110.0 * d);
        float start = left + (((off % period) + period) % period);
        float y0 = top + 12f * d, y1 = top + 30f * d;
        for (float x = start; x < right; x += period) {
            c.drawLine(x, y0, x, y1, tick);
        }
        c.restore();

        float cx = w / 2f;
        c.drawLine(cx, top + 5f * d, cx, top + 34f * d, needle);

        c.drawRect(left, top, right, bottom, mask);
        c.restoreToCount(sc);
    }
}
