package com.camera.app;

import android.graphics.ColorMatrix;

/** Same five looks as the old web UI, as native color matrices. */
final class Filters {
    private Filters() {}

    static final int COUNT = 5; // none, mono, sepia, vivid, warm

    static ColorMatrix contrast(float c) {
        float t = (0.5f - 0.5f * c) * 255f;
        return new ColorMatrix(new float[]{
                c, 0, 0, 0, t,
                0, c, 0, 0, t,
                0, 0, c, 0, t,
                0, 0, 0, 1, 0});
    }

    static ColorMatrix brightness(float b) {
        return new ColorMatrix(new float[]{
                b, 0, 0, 0, 0,
                0, b, 0, 0, 0,
                0, 0, b, 0, 0,
                0, 0, 0, 1, 0});
    }

    static ColorMatrix saturate(float s) {
        ColorMatrix m = new ColorMatrix();
        m.setSaturation(s);
        return m;
    }

    static ColorMatrix sepia(float a) {
        float k = 1f - a;
        return new ColorMatrix(new float[]{
                0.393f + 0.607f * k, 0.769f - 0.769f * k, 0.189f - 0.189f * k, 0, 0,
                0.349f - 0.349f * k, 0.686f + 0.314f * k, 0.168f - 0.168f * k, 0, 0,
                0.272f - 0.272f * k, 0.534f - 0.534f * k, 0.131f + 0.869f * k, 0, 0,
                0, 0, 0, 1, 0});
    }

    static ColorMatrix hueRotate(float deg) {
        double r = Math.toRadians(deg);
        float c = (float) Math.cos(r), s = (float) Math.sin(r);
        return new ColorMatrix(new float[]{
                0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f, 0, 0,
                0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f, 0, 0,
                0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f, 0, 0,
                0, 0, 0, 1, 0});
    }

    /** Returns null when no look is active. */
    static ColorMatrix matrixFor(int filterIdx, boolean beauty) {
        if (filterIdx == 0 && !beauty) return null;
        ColorMatrix m = new ColorMatrix();
        switch (filterIdx) {
            case 1:
                m.postConcat(saturate(0f));
                break;
            case 2:
                m.postConcat(sepia(0.8f));
                break;
            case 3:
                m.postConcat(saturate(1.7f));
                m.postConcat(contrast(1.1f));
                break;
            case 4:
                m.postConcat(contrast(1.2f));
                m.postConcat(brightness(1.05f));
                m.postConcat(hueRotate(-12f));
                break;
            default:
                break;
        }
        if (beauty) {
            m.postConcat(brightness(1.06f));
            m.postConcat(contrast(0.95f));
        }
        return m;
    }
}
